<?php
class AssertionExample
{
    public function doSomething()
    {
        assert(false);
    }
}
